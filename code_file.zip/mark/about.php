<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>About Us - Marken Cyber LLC</title>
   <meta name="description" content="Combining people, processes, and technology to solve, detect and respond to Cyber Security compliance incidents in real time.">
  <meta name="keywords" content="cybersecurity,cybersecurity news,nist cybersecurity framework,cybersecurity jobs,what is cybersecurity,cybersecurity certificate,cybersecurity training,cybersecurity companies,cybersecurity courses,cybersecurity scholarships,cybersecurity careers,cybersecurity and infrastructure security agency,cybersecurity salary,cybersecurity definition,cybersecurity framework,top cybersecurity companies,is cybersecurity stressful,cybersecurity awareness mont,wgu cybersecurity,cybersecurity internship,cybersecurity certifications,cybersecurity for beginners,cybersecurity certification,does cybersecurity pay well,washington post cybersecurity 202,cybersecurity degree,cybersecurity statistics,cybersecurity analyst,women in cybersecurity
  ,ironnet cybersecurity,does cybersecurity require coding,cybersecurity stocks,cybersecurity bootcamp,entry level cybersecurity jobs,cybersecurity or cyber security,equifax cybersecurity incident website,cybersecurity law,what skills do i need for cybersecurity,cybersecurity month,cybersecurity internships, cybersecurity maturity model certification, at&t cybersecurity,is cybersecurity a good career,cybersecurity programs,fidelis cybersecurity,cybersecurity conferences 2019,umuc cybersecurity,cybersecurity attacks,cybersecurity masters,cybersecurity issues,national cybersecurity awareness month,cisco cybersecurity, why is cybersecurity important,define cybersecurity,cybersecurity reddit,why cybersecurity,cybersecurity threats,cybersecurity tools,cybersecurity fatigue,nist cybersecurity,cybersecurity services,cybersecurity minor tamu,virginia cybersecurity,cyber security or cybersecurity,usf cybersecurity,mit cybersecurity,cybersecurity etf,umbc cybersecurity,ai cybersecurity,cybersecurity average salary,national cybersecurity center,cybersecurity in the public sector,cybersecurity soc,cybersecurity job outlook,cybersecurity information sharing action">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/venobox/venobox.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">

  <!--  CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

</head>

<body>

   <!-- ======= Header ======= -->
  <div class="header-toparea">
                <div class="container">
                    <div class="row">
                        <div class="col-md-7 col-sm-8 col-12">
                            <div class="header-topinfo">
                                <ul>
                                    <li><a href="tel://+703-232-3226"><i class="icofont-ui-call"></i>
                                            +703-232-3226</a></li>
                                    <li><a href="mailto://Markencyberllc@gmail.com"><i class="icofont-email"></i>
                                            Markencyberllc@gmail.com</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-md-5 col-sm-4 col-12">
                            <div class="header-topsocial">
                                <ul>
                                    <li><a href="https://twitter.com/LlcMarken"><i class="icofont-twitter"></i></a></li>
                                    <li><a href="https://web.facebook.com/Marken-CyberLLC-104676797990824"><i class="icofont-facebook"></i></a></li>
                                    <li><a href="https://instagram.com/markencyberllc?igshid=1bcdqszplkuzo"><i class="icofont-instagram"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
      </div>
  <header id="header" class="sticky-top">
    <div class="container-fluid">
      <div class="row justify-content-center">
        <div class="col-xl-10 d-flex align-items-center">
          <h1 class="logo mr-auto"><a href="index.html">Marken Cyber LLC</a></h1>
          <!-- <a href="index.html" class="logo mr-auto"><img src="assets/img/logo.png" alt=""></a>-->

          <nav class="nav-menu d-none d-lg-block">
            <ul>
              <li><a href="index.html">Home</a></li>
              <li class="active"><a href="about.html">About Us</a></li>
               <li class="drop-down"><a href="service.html">Services</a>
                <ul>
                  <li><a href="#">Drop Down 1</a></li>
                  <li><a href="#">Drop Down 2</a></li>
                </ul>
              </li>
              <li><a href="#">Careers</a></li>
              <li><a href="blog.html">Blogs</a></li>  
              <li><a href="contact.html">Contact</a></li>
                         <li><a href="#0"  id="search"><i class="icofont icofont-search" ></i></a></li>
            </ul>
          </nav><!-- .nav-menu -->

          
        </div>
      </div>

    </div>
     
  </header><!-- End Header -->
     <div class="search_input" id="search_input_box">
          <div class="container">
            <form class="d-flex justify-content-between" method="" action="">
              <input
                type="text"
                class="form-control"
                id="search_input"
                placeholder="Search Here"
              />
                <button type="submit" class="btn"><i class="icofont-swoosh-right"></i> </button>
              <span
                class="icofont-close"
                id="close_search"
                title="Close Search"
              ></span>
            </form>
          </div>
        </div>


  <main id="main">

    <!-- ======= Breadcrumbs ======= -->
    <section class="breadcrumbs">
      <div class="container">

        <ol>
          <li><a href="index.html">Home</a></li>
          <li>About Us</li>
        </ol>
        <h2>About Us</h2>

      </div>
    </section><!-- End Breadcrumbs -->

    <!-- ======= About Us Section ======= -->
     <section class="abouts">
      <div class="container">
        <div class="row">
          <div class="col-md-4 col-lg-4">
            <div class="container">
              <img src="assets/img/about-logo.jpg" class="img-fluid card shadow">
            </div>
          </div>
           <div class="col-md-8 col-lg-8">
              <h2>About Marken Cyber LLC</h2>
            
              <p>The Marken Team has led or participated in the development of national planning for cyber and critical infrastructure protection security activities for more than 15 years. We provide Expertise and Leadership.
                  Marken is a different kind of consultancy – We are National Security and Emergency Preparedness Professionals who care.</p>

              <p>The Marken Team has led or participated in the development of national planning for cyber and critical infrastructure protection security activities for more than 15 years. We provide Expertise and Leadership.
                  Marken is a different kind of consultancy – We are National Security and Emergency Preparedness Professionals who care.Marken is a different kind of consultancy – We are National Security and Emergency Preparedness Professionals who care.</p>
                  <p>The Marken Team has led or participated in the development of national planning for cyber and critical infrastructure protection security activities for more than 15 years. We provide Expertise and Leadership.
                  Marken is a different kind of consultancy – We are National Security and Emergency Preparedness Professionals who care.</p>

              <p>The Marken Team has led or participated in the development of national planning for cyber and critical infrastructure protection security activities for more than 15 years. We provide Expertise and Leadership.
                  Marken is a different kind of consultancy – We are National Security and Emergency Preparedness Professionals who care.Marken is a different kind of consultancy – We are National Security and Emergency Preparedness Professionals who care.</p>
          </div>
        </div>
       

      </div>
    </section>
    <section class="abouts">
      <div class="container">
        <div class="row">
          
           <div class="col-md-6 col-lg-6">
              <h2>Marken Cybersecurity</h2>
              <p>The Marken Team has led or participated in the development of national planning for cyber and critical infrastructure protection security activities for more than 15 years. We provide Expertise and Leadership.
                  Marken is a different kind of consultancy – We are National Security and Emergency Preparedness Professionals who care.</p>

              <h2>Cybersecurity</h2>
              <p>The Marken Team has led or participated in the development of national planning for cyber and critical infrastructure protection security activities for more than 15 years. We provide Expertise and Leadership.
                  Marken is a different kind of consultancy – We are National Security and Emergency Preparedness Professionals who care.Marken is a different kind of consultancy – We are National Security and Emergency Preparedness Professionals who care.</p>
          </div>
          <div class="col-md-6 col-lg-6">
            <div class="container">
              <img src="assets/img/cyber1.jpg" class="img-fluid card shadow-lg">
            </div>
          </div>
        </div>
       

      </div>
    </section>
     <section class="para">
      <div class="container">
      <!--   <p>MARKEN Cybersecurity’s approach for larger enterprises is built on a set of risk management principles. We begin with education and infuse a suite of services supporting risk reducing activities. Our concepts engage the customer and builds long term partnerships through trusted relationships. We deliver expertise that provides peace of mind to clients and the subject matter expertise to reduce chances cascading effects will occur should there be a breach occur.</p> -->
        <!-- <ul>
          <li>
          Department of Homeland Cyber Leadership
            
          </li>
          <li>
White House Policy Recommendation
            
          </li>
          <li>
National Infrastructure Plan Management
            
          </li>
          <li>
Facilitator of Public-Private Partnership
            
          </li>
          <li>
Fiber and Cable Installation

            
          </li>
          <li>
Cybersecurity Exercises in Major U.S. Cities

            
          </li>
          <li>
Large and Complex Risk Assessments
            
          </li>
          <li>
Amtrak Technology Pilot Architect
            
          </li>
          <li>
White House Policy Recommendation
            
          </li>
          <li>
National Infrastructure Plan Management
            
          </li>
          <li>
Facilitator of Public-Private Partnership
            
          </li>
          <li>
Fiber and Cable Installation

            
          </li>
          <li>
Cybersecurity Exercises in Major U.S. Cities

            
          </li>
          <li>
Large and Complex Risk Assessments
            
          </li>
          <li>
Amtrak Technology Pilot Architect
            
          </li>
        </ul> -->
      <!--   <p><b>Critical Infrastructure Protection</b> Our critical infrastructure team is focused on preventing outages and resolving them should they occur.  We provide access to critical systems and products such as liquid nitrogen and building capabilities. Our physical plant team is the best in the world at energy regeneration and restoration management. We grow with our customers and not because of them. Our team helped to write the National Response Framework and National Infrastructure Protection Plan.</p>
        <br>
        <p>cybersecurity is a leading cybersecurity service consultant and well-known cybersecurity company Washington DC.</p> -->



      </div>
    </section>
   

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer">

    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-3 col-md-6 footer-contact">
            <h3>Marken Cyber LLC</h3>
            <p>
              Dumfries, VA<br><br>
              <strong>Phone:</strong> +703-232-3226<br>
              <strong>Email:</strong> Markencyberllc@gmail.com<br>
            </p>
          </div>

          <div class="col-lg-2 col-md-6 footer-links">
            <h4>Useful Links</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Home</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">About us</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Services</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Terms of service</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Privacy policy</a></li>
            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Recent Posts</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="#">cyber threat information</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">cyber security protection tips</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">how you will secure</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Marken CyberSecurity</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Cyber Security compliance</a></li>
            </ul>
          </div>

          <div class="col-lg-4 col-md-6 footer-newsletter">
            <h4>Join Our Newsletter</h4>
            <p>To schedule an appointment with our consultancy firm,contact  via phone or email.</p>
            <form action="" method="post">
              <input type="email" name="email"><input type="submit" value="Subscribe">
            </form>
          </div>

        </div>
      </div>
    </div>

    <div class="container d-md-flex py-4">

      <div class="mr-md-auto text-center text-md-left">
        <div class="copyright">
          &copy; Copyright <strong><span>Marken Cyber LLC</span></strong>. All Rights Reserved
        </div>
      </div>
      <div class="social-links text-center text-md-right pt-3 pt-md-0">
        <a href="https://twitter.com/LlcMarken" class="twitter"><i class="bx bxl-twitter"></i></a>
        <a href="https://web.facebook.com/Marken-CyberLLC-104676797990824" class="facebook"><i class="bx bxl-facebook"></i></a>
        <a href="https://instagram.com/markencyberllc?igshid=1bcdqszplkuzo" class="instagram"><i class="bx bxl-instagram"></i></a>
      </div>
    </div>
  </footer><!-- End Footer -->


  <a href="#" class="back-to-top"><i class="icofont-simple-up"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/jquery/jquery.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/jquery.easing/jquery.easing.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/owl.carousel/owl.carousel.min.js"></script>
  <script src="assets/vendor/waypoints/jquery.waypoints.min.js"></script>
  <script src="assets/vendor/counterup/counterup.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/venobox/venobox.min.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>