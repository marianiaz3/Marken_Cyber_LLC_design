<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>HOME - Marken Cyber LLC </title>
  <meta name="description" content="Combining people, processes, and technology to solve, detect and respond to Cyber Security compliance incidents in real time.">
  <meta name="keywords" content="cybersecurity,cybersecurity news,nist cybersecurity framework,cybersecurity jobs,what is cybersecurity,cybersecurity certificate,cybersecurity training,cybersecurity companies,cybersecurity courses,cybersecurity scholarships,cybersecurity careers,cybersecurity and infrastructure security agency,cybersecurity salary,cybersecurity definition,cybersecurity framework,top cybersecurity companies,is cybersecurity stressful,cybersecurity awareness mont,wgu cybersecurity,cybersecurity internship,cybersecurity certifications,cybersecurity for beginners,cybersecurity certification,does cybersecurity pay well,washington post cybersecurity 202,cybersecurity degree,cybersecurity statistics,cybersecurity analyst,women in cybersecurity
  ,ironnet cybersecurity,does cybersecurity require coding,cybersecurity stocks,cybersecurity bootcamp,entry level cybersecurity jobs,cybersecurity or cyber security,equifax cybersecurity incident website,cybersecurity law,what skills do i need for cybersecurity,cybersecurity month,cybersecurity internships, cybersecurity maturity model certification, at&t cybersecurity,is cybersecurity a good career,cybersecurity programs,fidelis cybersecurity,cybersecurity conferences 2019,umuc cybersecurity,cybersecurity attacks,cybersecurity masters,cybersecurity issues,national cybersecurity awareness month,cisco cybersecurity, why is cybersecurity important,define cybersecurity,cybersecurity reddit,why cybersecurity,cybersecurity threats,cybersecurity tools,cybersecurity fatigue,nist cybersecurity,cybersecurity services,cybersecurity minor tamu,virginia cybersecurity,cyber security or cybersecurity,usf cybersecurity,mit cybersecurity,cybersecurity etf,umbc cybersecurity,ai cybersecurity,cybersecurity average salary,national cybersecurity center,cybersecurity in the public sector,cybersecurity soc,cybersecurity job outlook,cybersecurity information sharing action">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->


  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/venobox/venobox.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">


  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">
</head>

<body>

  <!-- ======= Header ======= -->
  <div class="header-toparea">
                <div class="container">
                    <div class="row">
                        <div class="col-md-7 col-sm-8 col-12">
                            <div class="header-topinfo">
                                <ul>
                                    <li><a href="tel://+703-232-3226"><i class="icofont-ui-call"></i>
                                            +703-232-3226</a></li>
                                    <li><a href="mailto://Markencyberllc@gmail.com"><i class="icofont-email"></i>
                                            Markencyberllc@gmail.com</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-md-5 col-sm-4 col-12">
                            <div class="header-topsocial">
                                <ul>
                                    <li><a href="https://twitter.com/LlcMarken"><i class="icofont-twitter"></i></a></li>
                                    <li><a href="https://web.facebook.com/Marken-CyberLLC-104676797990824"><i class="icofont-facebook"></i></a></li>
                                    <li><a href="https://instagram.com/markencyberllc?igshid=1bcdqszplkuzo"><i class="icofont-instagram"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
      </div>
  <header id="header" class="sticky-top">
     
    <div class="container-fluid">
      <div class="row justify-content-center">
        <div class="col-xl-10 d-flex align-items-center">
          <h1 class="logo mr-auto"><a href="index.html">Marken Cyber LLC</a></h1>
          <!-- <a href="index.html" class="logo mr-auto"><img src="assets/img/logo.png" alt=""></a>-->

          <nav class="nav-menu d-none d-lg-block">
            <ul>
              <li class="active"><a href="index.html">Home</a></li>
              <li><a href="about.html">About Us</a></li>
               <li class="drop-down"><a href="service.html">Services</a>
                <ul>
                  <li><a href="#">Drop Down 1</a></li>
                  <li><a href="#">Drop Down 2</a></li>
                </ul>
              </li>
              <li><a href="#">Careers</a></li>
              <li><a href="blog.html">Blogs</a></li>  
              <li><a href="contact.html">Contact</a></li>
              <li><a href="#0"  id="search"><i class="icofont icofont-search" ></i></a></li>
            </ul>
          </nav><!-- .nav-menu -->

          
        </div>
      </div>

    </div>
     
  </header><!-- End Header -->
     <div class="search_input" id="search_input_box">
          <div class="container">
            <form class="d-flex justify-content-between" method="" action="">
              <input
                type="text"
                class="form-control"
                id="search_input"
                placeholder="Search Here"
              />
                <button type="submit" class="btn"><i class="icofont-swoosh-right"></i> </button>
              <span
                class="icofont-close"
                id="close_search"
                title="Close Search"
              ></span>
            </form>
          </div>
        </div>

  <!-- ======= Hero Section ======= -->
  <section id="hero" class="d-flex align-items-center">

    <div class="container-fluid" data-aos="zoom-out" data-aos-delay="100">
      <div class="row justify-content-center">
        <div class="col-xl-12">
          <div class="row">
            <div class="col-xl-8 offset-2 text-center">
              <h2>Always Secured</h2>
              <h3>To schedule an appointment with our consultancy firm,contact  via phone or email.</h3> 
            </div>
          </div>
          <div class="row">
            <div class="col-lg-12 col-12 col-sm-12 col-md-12 text-center">
               <a href="#0" class="btn-hero   mb-3">Contact Us</a>
            </div>      
          </div>
          
        </div>
      </div>

    </div>
         

  </section><!-- End Hero -->
  <main id="main">
    <!-- ======= Services Section ======= -->
    <section id="services" class="services">
      <div class="container-fluid">

        <div class="section-title">
          <h5>SERVICES</h5>
          <h2>Our Capability Provided</h2>
        </div>

        <div class="row justify-content-center">
          <div class="col-xl-10">
            <div class="row">
              <div class="col-lg-4 col-md-6 ">
                <div class="icon-box bg-blue">
                  <div class="icon"><i class="icofont-contrast"></i></div>
                <h4 class="title"><a href="">Additional information for the target market</a></h4>
                <p class="description">Silicon Valley, Washington DC, Maryland, Northern Virginia, Nationwide.</p>
                </div>
              </div>
              <div class="col-lg-4 col-md-6 ">
                <div class="icon-box bg-orange">
                  <div class="icon"><i class="icofont-clip"></i></div>
                <h4 class="title"><a href="">What makes you unique?</a></h4>
                <p class="description">We provide same day services and we tailored/customized our services to solve Cyber Security and IT Security related Challenges.</p>
                </div>
              </div>
              <div class="col-lg-4 col-md-6 ">
                <div class="icon-box bg-blue">
                  <div class="icon"><i class="icofont-gears"></i></div>
                <h4 class="title"><a href="">Cyber Threat Information Sharing Consulting</a></h4>
                <p class="description">Combining people, processes, and technology to solve, detect and respond to Cyber Security compliance incidents in real time.</p>
                </div>
              </div>
              
            </div>
          </div>
        </div>

      </div>
    </section><!-- End Services Section -->
    <!-- aproach -->
    <section class="approach">
        <div class="container">
           <div class="row">
              <div class="col-lg-6 col-md-6 col-sm-12 col-12">
                <h1>Approach</h1>
                 <h2 class="pr-5 gold">Mission Statement</h2>
                 <p class="pr-3">
                  Combining people, processes, and technology to solve, detect and respond to Cyber Security compliance incidents in real time.What makes you unique? – We provide same day services and we tailored/customized our services to solve Cyber Security and IT Security related Challenges.</p>
                 <h2 class="pr-5 gold">What makes you unique?</h2>
                 <p class="pr-3">
                   We provide same day services and we tailored/customized our services to solve Cyber Security and IT Security related Challenges.</p>

                 <br>
                 <a href="" class="btn-round bg">See More</a>

              </div>
              <div class="col-lg-6 col-md-6 col-sm-12 col-12">
                <div class="container img-margin">
                <img src="assets/img/digital.jpg" class="img-fluid card shadow">
                  
                </div>
              </div>
           </div>
        </div>
    </section>
    <section class="approach">
        <div class="container">
           <div class="row">
              <div class="col-lg-4 col-md-4 col-sm-12 col-12 mb-5 text-center">
                <img src="assets/img/DHS.png" class="img-fluid" style="max-width: 100%;
    height: auto; width:160px">
              </div>
              
              <div class="col-lg-4 col-md-4 col-sm-12 col-12 mb-5 text-center">
                <img src="assets/img/doj.jpg" class="img-fluid ">
              </div>
              <div class="col-lg-4 col-md-4 col-sm-12 col-12 mb-5 text-center">
                <img src="assets/img/ba.png" class="img-fluid " style="max-width: 100%;
    height: auto; width:160px">
              </div>
           </div>
          <!--  <div class="row">
              <div class="col-lg-3">
                <img src="assets/img/USACE_Logo.jpg" class="img-fluid ">
              </div>
              <div class="col-lg-3">
                <img src="assets/img/dhs_tsa_small.jpg" class="img-fluid ">
              </div>
              <div class="col-lg-3">
                <img src="assets/img/jta_logo_wordmark_full-color.jpg" class="img-fluid ">
              </div>
              <div class="col-lg-3">
                <img src="assets/img/SBA-8A-Certified.jpg" class="img-fluid ">
              </div>
           </div> -->
        </div>
    </section>

     <section class="approach about">
        <div class="container">
           <div class="row">
              <div class="col-lg-12">
                <!-- <h1>Approach</h1> -->
                 <h2 class="pr-5 gold">Marken CyberSecurity</h2>
                 <p class="pr-3 text-white">Mission Statement – Combining people, processes, and technology to solve, detect and respond to Cyber Security compliance incidents in real time.<br><br>

Our extensive partnerships, built over many years of quality services, assures the right support when it is most needed. We recognize that our customers depend on us to provide the consultancy and guidance that assures their decisions are fact-based and sound.<br><br>

Our approach for managing risk is built on a set of principles that demand we meet the customer’s requirements. We begin with listening, followed by sharing our experience. Only then do we infuse a suite of services supporting risk-reducing activities. Our concepts engage the customer and build long-term partnerships – through trusted engagements.<br>

We deliver expertise that helps our clients to see the value in their investment. Our subject matter expertise helps reduce chances cascading effects will not occur.  </p>
              </div>
           </div>
        </div>
    </section>
   
    

           

   

    <!-- ======= Contact Section ======= -->
    <section id="contact" class="contact">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h1>We're Here To Help!</h1>
        
        </div>

        <div class="row" data-aos="fade-up" data-aos-delay="100">

          <div class="col-lg-6">

            <div class="row">
              <div class="col-md-12">
                <div class="info-box">
                  <i class="bx bx-map"></i>
                  <h3>Our Address</h3>
                  <p>Dumfries, VA</p>
                </div>
              </div>
              <div class="col-md-6">
                <div class="info-box mt-4">
                  <i class="bx bx-envelope"></i>
                  <h3>Email Us</h3>
                  <p>Markencyberllc@gmail.com</p>
                </div>
              </div>
              <div class="col-md-6">
                <div class="info-box mt-4">
                  <i class="bx bx-phone-call"></i>
                  <h3>Call Us</h3>
                  <p>+703-232-3226</p>
                </div>
              </div>
            </div>

          </div>

          <div class="col-lg-6">
            <form action="forms/contact.php" method="post" role="form" class="php-email-form">
              <div class="form-row">
                <div class="col form-group">
                  <input type="text" name="name" class="form-control" id="name" placeholder="Your Name" data-rule="minlen:4" data-msg="Please enter at least 4 chars" />
                  <div class="validate"></div>
                </div>
                <div class="col form-group">
                  <input type="email" class="form-control" name="email" id="email" placeholder="Your Email" data-rule="email" data-msg="Please enter a valid email" />
                  <div class="validate"></div>
                </div>
              </div>
              <div class="form-group">
                <input type="text" class="form-control" name="subject" id="subject" placeholder="Subject" data-rule="minlen:4" data-msg="Please enter at least 8 chars of subject" />
                <div class="validate"></div>
              </div>
              <div class="form-group">
                <textarea class="form-control" name="message" rows="5" data-rule="required" data-msg="Please write something for us" placeholder="Message"></textarea>
                <div class="validate"></div>
              </div>
              <div class="mb-3">
                <div class="loading">Loading</div>
                <div class="error-message"></div>
                <div class="sent-message">Your message has been sent. Thank you!</div>
              </div>
              <div class="text-center"><button type="submit">Send Message</button></div>
            </form>
          </div>

        </div>

      </div>
    </section><!-- End Contact Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer">

    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-3 col-md-6 footer-contact">
            <h3>Marken Cyber LLC</h3>
            <p>
              Dumfries, VA<br><br>
              <strong>Phone:</strong> +703-232-3226<br>
              <strong>Email:</strong> Markencyberllc@gmail.com<br>
            </p>
          </div>

          <div class="col-lg-2 col-md-6 footer-links">
            <h4>Useful Links</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Home</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">About us</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Services</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Terms of service</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Privacy policy</a></li>
            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Recent Posts</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="#">cyber threat information</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">cyber security protection tips</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">how you will secure</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Marken CyberSecurity</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Cyber Security compliance</a></li>
            </ul>
          </div>

          <div class="col-lg-4 col-md-6 footer-newsletter">
            <h4>Join Our Newsletter</h4>
            <p>To schedule an appointment with our consultancy firm,contact  via phone or email.</p>
            <form action="" method="post">
              <input type="email" name="email"><input type="submit" value="Subscribe">
            </form>
          </div>

        </div>
      </div>
    </div>

    <div class="container d-md-flex py-4">

      <div class="mr-md-auto text-center text-md-left">
        <div class="copyright">
          &copy; Copyright <strong><span>Marken Cyber LLC</span></strong>. All Rights Reserved
        </div>
      </div>
      <div class="social-links text-center text-md-right pt-3 pt-md-0">
        <a href="https://twitter.com/LlcMarken" class="twitter"><i class="bx bxl-twitter"></i></a>
        <a href="https://web.facebook.com/Marken-CyberLLC-104676797990824" class="facebook"><i class="bx bxl-facebook"></i></a>
        <a href="https://instagram.com/markencyberllc?igshid=1bcdqszplkuzo" class="instagram"><i class="bx bxl-instagram"></i></a>
      </div>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top"><i class="icofont-simple-up"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/jquery/jquery.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/jquery.easing/jquery.easing.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/owl.carousel/owl.carousel.min.js"></script>
  <script src="assets/vendor/waypoints/jquery.waypoints.min.js"></script>
  <script src="assets/vendor/counterup/counterup.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/venobox/venobox.min.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>